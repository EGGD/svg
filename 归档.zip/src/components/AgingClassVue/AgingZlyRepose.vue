<template>
  <div>上报</div>
</template>

<script>
// 资料员时效类上报页面
export default {
  methods: {
    handleClick (row) {
      console.log(row)
    }
  },
  data () {
    return {

    }
  }
}
</script>
