import { api } from './api/funUrl'
// import axios from '../../config/axios'
import axios from '../../config/axios'
const state = {
  AgingTodoListData: []
}
const getters = {
  aTodoList: state => state.AgingTodoListData
}
const actions = {
  getATodoList ({ commit }, params) {
    return new Promise(function (resolve, reject) {
      axios.getAsync(commit, api.zlyTodoListUrl, params).then((value) => {
        console.log(value)
        resolve(value)
      }).catch(err => {
        reject(err)
      })
    })
  }
}
const mutations = {
  [api.zlyTodoListUrl] (state, data) {
    state.AgingTodoListData = data
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
