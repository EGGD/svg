const api = {
  // 资料员待办列表接口
  zlyTodoListUrl: 'api/AgingClass/GetAgingClassList'
}
export {
  api
}
