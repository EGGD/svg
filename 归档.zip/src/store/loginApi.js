const api = {
  loginUrl: 'api/User/Login',
  userAuthorityUrl: 'api/PhoneRole/GetMenusByUserId'
}
export {
  api
}
